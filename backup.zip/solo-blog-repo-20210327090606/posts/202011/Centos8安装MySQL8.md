title: Centos 8 安装MySQL8
date: '2020-11-11 11:16:45'
updated: '2020-11-11 14:10:00'
tags: [Linux, MySQL]
permalink: /articles/2020/11/11/1605064605139.html
---
![](https://b3logfile.com/bing/20200307.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**官方安装网址**：https://dev.mysql.com/doc/refman/8.0/en/linux-installation-yum-repo.html

**自行整理**

**MySQL安装**

```
# 添加源 根据自己的版本来
[root@localhost ~]# wget  https://repo.mysql.com/mysql80-community-release-el8-1.noarch.rpm

# 安装rpm包
[root@localhost ~]# rpm -ivh mysql80-community-release-el8-1.noarch.rpm

# 安装mysql
[root@localhost ~]# yum install mysql-server

# 启动服务
[root@localhost ~]# systemctl start mysqld

# 查看启动状态
[root@localhost ~]# systemctl status mysqld

# 查看MySQL版本
[root@localhost ~]# mysqladmin -u root -p version

#设置开机启动
[root@localhost ~]# systemctl enable mysqld
[root@localhost ~]# systemctl daemon-reload

# 查看开启动
[root@localhost ~]# systemctl list-unit-files|grep mysqld

# 结果
mysqld.service enabled
mysqld@.service disabled
```

**MySQL 初始化**

```
# 登录mysql，首次登录不需要密码
[root@localhost ~]# mysql

# 使用mysql
mysql> use mysql;

# 修改密码
mysql> ALTER USER 'root'@'localhost' IDENTIFIED BY 'Root@123';

# 刷新
mysql> FLUSH PRIVILEGES;

# 查看用户
mysql> select host, user from user;
+-----------+------------------+
| host      | user             |
+-----------+------------------+
| localhost | mysql.infoschema |
| localhost | mysql.session    |
| localhost | mysql.sys        |
| localhost | root             |
+-----------+------------------+
4 rows in set (0.00 sec)

# 修改root用户允许远程连接
mysql> update user set host='%' where user ='root';

# 刷新
mysql> FLUSH PRIVILEGES;

# 修改远程连接密码，这里的WITH mysql_native_password也可以去掉（Navicat连接需要这样）
mysql> ALTER USER 'root'@'%' IDENTIFIED WITH mysql_native_password BY 'Root@123';

# 查看用户
mysql> select host, user from user;
+-----------+------------------+
| host      | user             |
+-----------+------------------+
| %         | root             |
| localhost | mysql.infoschema |
| localhost | mysql.session    |
| localhost | mysql.sys        |
+-----------+------------------+

# 退出
mysql> exit
Bye
```

[记得开放端口 3306](https://xiaoyver.top/articles/2020/11/11/1605063488832.html)

