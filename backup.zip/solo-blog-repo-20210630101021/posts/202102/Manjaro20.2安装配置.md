title: Manjaro 20.2安装配置
date: '2021-02-03 17:04:11'
updated: '2021-02-03 22:46:08'
tags: [Linux, Manjaro]
permalink: /articles/2021/02/03/1612343051327.html
---
![](https://b3logfile.com/bing/20200801.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

近期换了工作，新公司的电脑可以随便折腾，于是做了个win10+Manjaro双系统

## 检查配置

* 检查计算管理-> 存储 -> 磁盘管理 -> 磁盘0或磁盘1（右击属性） -> 卷
* 磁盘分区形式：GPT 一般就是这样就是可以的
* 才磁盘的最后压缩出一定的空间，用来安装Manjaro，例如我的分出来100G（实际磁盘1最后面的166.02GB才是我安装的Manjaro，当时忘记截图了...）
  
  ![计算机管理](https://b3logfile.com/file/2021/02/image-0c84d1ca.png)
  
  ![磁盘管理](https://b3logfile.com/file/2021/02/image-edce3fd1.png)

## 制作镜像

* 下载镜像，一般使用迅雷比较快，至于下载什么桌面的，个人认为KDE可玩性高一些（可能是我太菜吧）：[下载地址](https://manjaro.org/downloads/official/kde/)
* 制作启动盘，我用的是Rufus，选择下载好的镜像，点击开始就好了（**以DD镜像 模式写入**）
  ![镜像工具](https://b3logfile.com/file/2021/02/image-08440912.png)

## 安装

* 安装没什么好说的，重启安装（本来不想写后面的步骤，但是发现U盘在边上，就重启了一下）

1. 重启进入Manjaro安装页面，可以把语言设置为中文
   
   ![启动菜单](https://b3logfile.com/file/2021/02/image-189f2050.png)
2. 点击安装程序开始安装
   
   ![启动安装](https://b3logfile.com/file/2021/02/image-f69d6284.png)
3. 选择语言、时区、键盘、用户、office等等
4. 选择分区时，模式选择取代一个分区，还要选择之前压缩的那一块，别选错了

![分区](https://b3logfile.com/file/2021/02/Screenshot20210204015147-66dd236d.png)

7. 安装完成重启就好了
8. 看一下安装完成的样子

![screenfetch](https://b3logfile.com/file/2021/02/深度截图选择区域20210203170749-1ecb5bcd.png)

![主页面](https://b3logfile.com/file/2021/02/深度截图选择区域20210203171401-33cfb57e.png)

