title: IDEA SpringBoot2 配置热部署
date: '2020-09-15 09:29:05'
updated: '2020-09-15 09:29:05'
tags: [IDEA, IDEA配置, SpringBoot热部署, SpringBoot]
permalink: /articles/2020/09/15/1600133345416.html
---
![](https://img.hacpai.com/bing/20200301.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

IDEA 版本：IntelliJ IDEA 2019.3.3
SpringBoot 版本：2.2.5.RELEASE

近期感觉记性不好了，把这个配置记下来

## 1. 添加热部署插件

更新 pom.xml，添加以下内容

```
<!--spring boot热部署-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <optional>true</optional> 
        </dependency>
```

## 2.修改IDEA配置

### 2.1开启 IDEA 的热部署策略

顶部菜单- >Edit Configurations->SpringBoot 插件-> 目标项目-> 勾选热更新

![深度截图选择区域20200320195141.png](https://img.hacpai.com/file/2020/03/深度截图选择区域20200320195141-5c5508d7.png)

2.2开启 IDEA 的自动编译
顶部工具栏 File -> Settings -> Default Settings -> Build -> Compiler 然后勾选 Build project automatically

![深度截图选择区域20200320200056.png](https://img.hacpai.com/file/2020/03/深度截图选择区域20200320200056-1cbcd90b.png)

### 2.3开启 IDEA 的自动编译

同时按住 Ctrl + Shift + Alt + / 然后进入 Registry ，勾选自动编译

![深度截图选择区域20200320202848.png](https://img.hacpai.com/file/2020/03/深度截图选择区域20200320202848-814af23a.png)

![深度截图jetbrainsidea20200320202911.png](https://img.hacpai.com/file/2020/03/深度截图jetbrainsidea20200320202911-2bd875cf.png)

## 3.项目配置

### 3.1添加配置

在配置文件中添加配置：spring.devtools.restart.trigger-file=version.txt
verion.txt创建的目录是在resources目录，里面的内容随便

![深度截图选择区域20200320203036.png](https://img.hacpai.com/file/2020/03/深度截图选择区域20200320203036-b35237f7.png)

### 3.2 项目使用

每次更改 version 内容，保存后，项目就会自动加载

![深度截图选择区域20200320203121.png](https://img.hacpai.com/file/2020/03/深度截图选择区域20200320203121-9eaf7872.png)


