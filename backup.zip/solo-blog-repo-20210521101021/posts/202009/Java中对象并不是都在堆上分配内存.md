title: Java中对象并不是都在堆上分配内存
date: '2020-09-15 09:30:12'
updated: '2020-09-15 09:30:12'
tags: [Java]
permalink: /articles/2020/09/15/1600133412477.html
---
![](https://img.hacpai.com/bing/20180616.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近在看Java虚拟机的一些东西，发现和之前学的知识有点出入，今天有时间记录一下

### JVM内存分配策略

先回顾一下JVM的内存结构及内存分配方式

1. 根据Java虚拟机规范，Java虚拟机所管理的内存包括方法区、虚拟机栈、本地方法栈、堆、程序计数器等。
2. 我们通常认为JVM中运行时数据存储包括堆和栈。这里所提到的栈其实指的是虚拟机栈，或者说是虚拟栈中的局部变量表。
3. 栈中存放一些基本类型的变量数据（int/short/long/byte/float/double/Boolean/char）和对象引用。
4. 堆中主要存放对象，即通过new关键字创建的对象。
5. 数组引用变量是存放在栈内存中，数组元素是存放在堆内存中。

### JIT

JIT是Just In Time compiler的简称，是运行时编译，能够加速java程序的执行速度，是JVM的重要一部分。
JIT的核心就是分析代码，优化运行效率。一方面是，代码可能写的不够最优，由JIT代替程序员做一些优化。另一方面是，程序代码本身没问题，但是cpu和内存的操作可以进一步优化，这些程序员并不知道，由JIT来帮程序员做了。
JIT并不总是奏效，不能期望JIT一定可以加速你代码运行的速度，更糟糕的是她有可能减少代码的运行速度。这取决于你的代码结构，当然非常多情况下我们还是可以如愿以偿的。

### 逃逸分析

在编译期间，JIT会对代码做很多优化，其中有一部分优化的目的就是减少内存堆分配压力，其中一种重要的技术叫做逃逸分析。
逃逸分析(Escape Analysis)是目前Java虚拟机中比较前沿的优化技术。这是一种可以有效减少Java 程序中同步负载和内存堆分配压力的跨函数全局数据流分析算法。通过逃逸分析，Java Hotspot编译器能够分析出一个新的对象的引用的使用范围从而决定是否要将这个对象分配到堆上。
逃逸分析的基本行为就是分析对象动态作用域：当一个对象在方法中被定义后，它可能被外部方法所引用，例如作为调用参数传递到其他地方中，称为方法逃逸。
代码展示：

```
public static StringBuffer craeteStringBuffer(String s1, String s2) {

        StringBuffer sb = new StringBuffer();
        sb.append(s1);
        sb.append(s2);
        return sb;
    }
```

StringBuffer sb是一个方法内部变量，上述代码中直接将sb返回，这样这个StringBuffer有可能被其他方法所改变，这样它的作用域就不只是在方法内部，虽然它是一个局部变量，称其逃逸到了方法外部。甚至还有可能被外部线程访问到，譬如赋值给类变量或可以在其他线程中访问的实例变量，称为线程逃逸。
上述代码如果想要StringBuffer sb不逃出方法，可以这样写：

```
public static String createStringBuffer(String s1, String s2) {

        StringBuffer sb = new StringBuffer();
        sb.append(s1);
        sb.append(s2);
        return sb.toString();
    }
```

不直接返回 StringBuffer，那么StringBuffer将不会逃逸出方法。
使用逃逸分析，编译器可以对代码做如下优化：
一、同步省略。如果一个对象被发现只能从一个线程被访问到，那么对于这个对象的操作可以不考虑同步。
二、将堆分配转化为栈分配。如果一个对象在子程序中被分配，要使指向该对象的指针永远不会逃逸，对象可能是栈分配的候选，而不是堆分配。
三、分离对象或标量替换。有的对象可能不需要作为一个连续的内存结构存在也可以被访问到，那么对象的部分（或全部）可以不存储在内存，而是存储在CPU寄存器中。
在Java代码运行时，通过JVM参数可指定是否开启逃逸分析， -XX:+DoEscapeAnalysis ： 表示开启逃逸分析 -XX:-DoEscapeAnalysis ： 表示关闭逃逸分析 从jdk 1.7开始已经默认开始逃逸分析，如需关闭，需要指定-XX:-DoEscapeAnalysis

### 对象的栈上内存分配

我们知道，在一般情况下，对象和数组元素的内存分配是在堆内存上进行的。但是随着JIT编译器的日渐成熟，很多优化使这种分配策略并不绝对。JIT编译器就可以在编译期间根据逃逸分析的结果，来决定是否可以将对象的内存分配从堆转化为栈。
代码展示：

```
public static void main(String[] args) {

        long a1 = System.currentTimeMillis();

        for (int i = 0; i < 1000000; i++) {
            alloc();
        }
        // 查看执行时间
        long a2 = System.currentTimeMillis();
        System.out.println("cost " + (a2 - a1) + " ms");
        // 为了方便查看堆内存中对象个数，线程sleep
        try {
            Thread.sleep(100000);
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }
    }

    private static void alloc() {
        User user = new User();
    }

    static class User {

    }
```

代码内容是，使用for循环，在代码中创建100万个User对象。
我们在alloc方法中定义了User对象，但是并没有在方法外部引用他。也就是说，这个对象并不会逃逸到alloc外部。经过JIT的逃逸分析之后，就可以对其内存分配进行优化。
不开启逃逸分析
指定启动参数

```
-Xmx4G -Xms4G -XX:-DoEscapeAnalysis -XX:+PrintGCDetails -XX:+HeapDumpOnOutOfMemoryError
```

结果

```
λ jps
2812 Jps
8108 Main

λ jmap -histo 8108

 num     #instances         #bytes  class name
----------------------------------------------
   1:           659       67277880  [I
   2:       1000000       16000000  com.liu.Main$User
   3:          1211        1174904  [B
   4:          7771         909712  [C
   5:          5928         142272  java.lang.String
   6:           692          79088  java.lang.Class
```

从上面的jmap执行结果中我们可以看到，堆中共创建了100万个StackAllocTest$User实例。

开启逃逸分析
指定启动参数

```
-Xmx4G -Xms4G -XX:-DoEscapeAnalysis -XX:+PrintGCDetails -XX:+HeapDumpOnOutOfMemoryError
```

结果

```
λ jps
11332 Jps
4580 Main

λ jmap -histo 4580

 num     #instances         #bytes  class name
----------------------------------------------
   1:           659       80663704  [I
   2:        163401        2614416  com.liu.Main$User
   3:          1211        1174904  [B
   4:          7768         909544  [C
   5:          5925         142200  java.lang.String
   6:           692          79088  java.lang.Class
```

从上面的jmap执行结果中我们可以看到，堆中共创建了16万个StackAllocTest$User实例。

在关闭逃避分析的情况下（-XX:-DoEscapeAnalysis），虽然在alloc方法中创建的User对象并没有逃逸到方法外部，但是还是被分配在堆内存中。也就说，如果没有JIT编译器优化，没有逃逸分析技术，正常情况下就应该是这样的。即所有对象都分配到堆内存中。
开启了逃逸分析之后（-XX:+DoEscapeAnalysis），在堆内存中只有16万多个StackAllocTest$User对象。也就是说在经过JIT优化之后，堆内存中分配的对象数量，从100万降到了16万。

### 总结

不是所有的对象和数组都会在堆内存分配空间，随着JIT编译器的发展，在编译期间，如果JIT经过逃逸分析，发现有些对象没有逃逸出方法，那么有可能堆内存分配会被优化成栈内存分配。但是这也并不是绝对的。就像我们前面看到的一样，在开启逃逸分析之后，也并不是所有User对象都没有在堆上分配。


