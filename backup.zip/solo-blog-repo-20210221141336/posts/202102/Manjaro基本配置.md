title: Manjaro 基本配置
date: '2021-02-20 15:41:55'
updated: '2021-02-20 22:06:10'
tags: [Manjaro, Linux]
permalink: /articles/2021/02/20/1613806915343.html
---
![](https://b3logfile.com/bing/20180813.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 更新

### 切换源

1. 选择最快的源
   选择个最快的，我个人喜欢中科大的源(mirrors.ustc.edu.cn)或者清华的源(mirrors.tuna.tsinghua.edu.cn)

```
sudo pacman-mirrors -i -c China -m rank
sudo pacman -Syy
```

2. 添加arch源
   修改`/etc/pacman.conf`,在文件末尾添加

```
vi /etc/pacman.conf
#文件末尾添加
[archlinuxcn]
SigLevel = Optional TrustedOnly
Server = https://mirrors.ustc.edu.cn/archlinuxcn/$arch
```

### 更新系统

```
#安装签名
sudo pacman -S archlinuxcn-keyring
#更新系统
sudo pacman -Syyu
```

## 必备软件

### yay包管理器

```
sudo pacman -S yay
```

### 搜狗输入法

```
yay -S fcitx-lilydjwg-git
yay -S fcitx-sogoupinyin
#可能会报错
#==> 错误： Cannot find the fakeroot binary.
#生成时出错: fcitx-sogoupinyin
#因为没安装 fakeroot、binutils 等打包基本工具
#安装打包工具
sudo pacman -S base-devel
yay -S  kcm-fcitx 
#安装完成后重启就可以
```

### 谷歌浏览器

```
sudo pacman -S google-chrome
```

### 微信

```
yay -S deepin-wine-wechat
切换到deepin-wine环境：
/opt/apps/com.qq.weixin.deepin/files/run.sh -d
```

## 个人软件

```
sudo pacman -S vim #vim神器
```

参考：https://zhuanlan.zhihu.com/p/114296129

