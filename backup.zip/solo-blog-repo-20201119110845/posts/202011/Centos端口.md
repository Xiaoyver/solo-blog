title: Centos 端口
date: '2020-11-11 10:58:09'
updated: '2020-11-11 10:58:09'
tags: [Linux, Centos, 端口]
permalink: /articles/2020/11/11/1605063488832.html
---
![](https://b3logfile.com/bing/20190111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

Centos 8  端口相关

1. 查看开放端口
   
   ```
   firewall-cmd --list-ports
   ```
2. 开放端口（开放端口需要reload）
   
   ```
   firewall-cmd --zone=public --add-port=3306/tcp --permanent
   ```
3. 关闭端口（关闭端口需要reload）
   
   ```
   firewall-cmd --zone=public --remove-port=3306/tcp --permanent
   ```
4. reload防火墙
   
   ```
   firewall-cmd --reload
   ```
5. 开启防火墙
   
   ```
   systemctl start firewalld
   ```
6. 关闭防火墙
   
   ```
   systemctl stop firewalld
   ```
7. 查看防火墙状态
   
   ```
   systemctl status firewalld
   ```
8. 开机启动防火墙
   
   ```
   systemctl enable firewalld
   ```
9. 禁止开机启动防火墙
   
   ```
   systemctl disable firewalld
   ```
10. 查看防火墙开机是否启动
    
    ```
    systemctl list-unit-files|grep firewalld
    ```


