title: FRP 本机映射到外网
date: '2020-09-15 09:31:47'
updated: '2020-09-15 09:31:47'
tags: [frp, 内网穿透]
permalink: /articles/2020/09/15/1600133507114.html
---
![](https://img.hacpai.com/bing/20181013.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

FRP 的GitHub地址：[传送门](https://github.com/fatedier/frp)

**先决条件：**

* 有一台公网的VPS（我买了一个阿里云的，自己玩）
* 有一台可以正常上网的电脑

这里只是在Centos上尝试使用，仅是个人日常使用，未用于生产环境

下载对应的压缩包，解压，[下载地址在Github上面](https://github.com/fatedier/frp/releases)
把frps 和 frps.ini 放到VPS上面，然后启动

```
/opt/frp/frps -c /opt/frp/frps.ini
```

把frpc 和 frpc.ini 放到本地的电脑上面，然后启动

```
/opt/frp/frpc -c /opt/frp/frpc.ini
```

记得开放相关的端口，VPS记得开放安全组

然后就可以通过公网IP+端口访问本地电脑了。

```
ssh -oPort6000 root@123.456.789.1
```

我的一些配置：

```
# frps.ini
[common]
bind_port = 6060
vhost_http_port = 8080
```

```
# frpc.ini
[common]
server_addr = 123.456.789.1
server_port = 6060

[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 600

# 转发8080端口
[8080端口]
type = http
remote_port = 8080
local_port = 8080
custom_domains = 123.456.789.1
```

```
# 客户端的启动（重启）脚本，因为远程使用，frp一定是启动的😂 
#/bin/bash
server_path="/opt/frp"
process_pid=`ps -ef | grep $server_path |grep -v color |grep -v grep | awk '{print $2}'`
kill -9 $process_pid
nohup /opt/frp/frpc -c /opt/frp/frpc.ini &
```



