title: 记一次Nginx迁移异常
date: '2020-10-22 22:22:52'
updated: '2020-10-23 09:26:22'
tags: [Nginx, 异常]
permalink: /articles/2020/10/22/1603376572537.html
---
![](https://b3logfile.com/bing/20200818.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## Nginx异常

Solo的原来部署的VPS快到期了，换了另一家性价比更好的。前几天在搞迁移，一切都很顺利，但是域名访问时 **502异常了**。

检查相关的启动脚本，都是从原来的服务器上复制过来的，应该都没问题才对。

放开solo的端口后，可以访问，只是页面内容乱了而已，由此确定是Nginx的问题。

查看日志后

```
tail -fn 20 /var/log/nginx/access.log
```

```
2020/10/21 15:20:26 [crit] 17498#17498: *1 connect() to 127.0.0.1:8080 failed (13: Permission denied) while connecting to upstream, client: 110.53.177.181, server: xiaoyver.top, request: "GET / HTTP/1.1", upstream: "http://127.0.0.1:8080/", host: "www.xiaoyver.top"
2020/10/21 15:20:26 [warn] 17498#17498: *1 upstream server temporarily disabled while connecting to upstream, client: 110.53.177.181, server: xiaoyver.top, request: "GET / HTTP/1.1", upstream: "http://127.0.0.1:8080/", host: "www.xiaoyver.top"
2020/10/21 15:20:26 [crit] 17498#17498: *1 connect() to [::1]:8080 failed (13: Permission denied) while connecting to upstream, client: 110.53.177.181, server: xiaoyver.top, request: "GET / HTTP/1.1", upstream: "http://[::1]:8080/", host: "www.xiaoyver.top"
2020/10/21 15:20:26 [warn] 17498#17498: *1 upstream server temporarily disabled while connecting to upstream, client: 110.53.177.181, server: xiaoyver.top, request: "GET / HTTP/1.1", upstream: "http://[::1]:8080/", host: "www.xiaoyver.top"
```

## 百度问题

```
connect() to 127.0.0.1:8080 failed (13: Permission denied) while connecting to upstream
```

百度了一圈都是一样的，说是权限的问题。

解决方式（我的是Centos7）：

1. 关闭SeLinux
   
   ```
   # 临时关闭，重启系统后还会开启。
   setenforce 0
   # 永久关闭
   vim /etc/selinux/config
   # 将SELINUX=enforcing改为SELINUX=disabled
   ```
2. 执行命令

```
sudo setsebool -P httpd_can_network_connect 1

```





## 知其依然而不知其所以然

既然百度只给了解决的方式，没说明问题，只能去Google喽！
可以参考stackoverflow
[链接1](https://stackoverflow.com/questions/23948527/13-permission-denied-while-connecting-to-upstreamnginx)
[链接2](https://stackoverflow.com/questions/21820444/nginx-error-13-permission-denied-while-connecting-to-upstream)

