title: Manjaro 基本配置
date: '2021-02-20 15:41:55'
updated: '2021-02-21 14:29:26'
tags: [Manjaro, Linux]
permalink: /articles/2021/02/20/1613806915343.html
---
![](https://b3logfile.com/bing/20180813.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 更新

### 切换源

1. 选择最快的源
   选择个最快的，我个人喜欢中科大的源(mirrors.ustc.edu.cn)或者清华的源(mirrors.tuna.tsinghua.edu.cn)

```
sudo pacman-mirrors -i -c China -m rank
sudo pacman -Syy
```

2. 添加arch源
   修改`/etc/pacman.conf`,在文件末尾添加

```
vi /etc/pacman.conf
#文件末尾添加
[archlinuxcn]
SigLevel = Optional TrustedOnly
Server = https://mirrors.ustc.edu.cn/archlinuxcn/$arch
```

### 更新系统

```
#安装签名
sudo pacman -S archlinuxcn-keyring
#更新系统
sudo pacman -Syyu
```

## 必备软件

### yay包管理器

```
sudo pacman -S yay
```

### 搜狗输入法

```
yay -S fcitx-lilydjwg-git
yay -S fcitx-sogoupinyin
#可能会报错
#==> 错误： Cannot find the fakeroot binary.
#生成时出错: fcitx-sogoupinyin
#因为没安装 fakeroot、binutils 等打包基本工具
#安装打包工具
sudo pacman -S base-devel
yay -S  kcm-fcitx 
#安装完成后重启就可以
```

### 谷歌浏览器

```
sudo pacman -S google-chrome
```

### 微信

```
yay -S deepin-wine-wechat
切换到deepin-wine环境：
/opt/apps/com.qq.weixin.deepin/files/run.sh -d
```

## 个人使用软件

```
#vim神器
yay -S vim 

#编辑器
yay -S visual-studio-code-bin 

#接口请求工具
yay -S postman 

#git客户端
yay -S gitkraken 

#SQL客户端
yay -S dbeaver 

#网易云音乐
yay -S netease-cloud-music 

#snaps商店安装RDM(Redis客户端)
yay -S snapd
sudo systemctl enable --now snapd.socket
sudo ln -s /var/lib/snapd/snap /snap
#Redis客户端
sudo snap install redis-desktop-manager 

#To Do List
sudo snap install todoist 

#JDK
yay -S jdk11-openjdk 

#SSH客户端管理工具
rm -f finalshell_install_linux.sh ;wget www.hostbuf.com/downloads/finalshell_install_linux.sh;chmod +x finalshell_install_linux.sh;./finalshell_install_linux.sh;

#IntelliJ IDEA
#下载，解压，配置快捷方式(桌面右击->新建->链接到应用程序)

#科学上网，记得配置v2ray的核心模块
yay -S qv2ray
```

参考：https://zhuanlan.zhihu.com/p/114296129

