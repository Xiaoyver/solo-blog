title: 'Linux '
date: '2020-11-11 11:11:29'
updated: '2020-11-11 11:23:21'
tags: [Linux]
permalink: /articles/2020/11/11/1605064289391.html
---
![](https://b3logfile.com/bing/20191209.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## Linux 命令

### 服务安装

* [Centos8安装MySQL](https://xiaoyver.top/articles/2020/11/11/1605064605139.html)

### 端口相关

* [开放端口](https://xiaoyver.top/articles/2020/11/11/1605063488832.html)

